package com.brub.ticketer.model;

public enum Sector {
    FINANCEIRO, EAD, SECRETARIA;
}
