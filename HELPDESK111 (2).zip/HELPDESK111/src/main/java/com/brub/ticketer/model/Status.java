package com.brub.ticketer.model;

public enum Status {
    ABERTO, EM_ANDAMENTO, FINALIZADO;
}
