package com.brub.ticketer.repository;

import com.brub.ticketer.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findByAgentNullAndSector(Sector sector);
    List<Ticket> findByStudentId(long studentId);
    List<Ticket> findByStatusAndStudentId(Status status, Long id);
    List<Ticket> findByAgentIdAndSector(long id, Sector sector);
    // Trouver tous les tickets d'un secteur avec un statut spécifique
    List<Ticket> findByStatusAndSector(Status status, Sector sector);
    List<Ticket> findByPriorityAndStudentId(Priority priority, Long id);
    List<Ticket> findBySector(Sector sector);
    List<Ticket> findByPriorityAndSector(Priority priority, Sector sector);
    List<Ticket> findBySectorAndAgentIdNot(Sector sector, Long agentId);



    // Ajout d'une méthode pour trouver des tickets avec filtrage multiple
    @Query("SELECT t FROM Ticket t WHERE (:status is null OR t.status = :status) AND (:priority is null OR t.priority = :priority) AND t.student.id = :studentId ORDER BY t.priority DESC, t.creationDate DESC")
    List<Ticket> findTicketsWithFilters(Status status, Priority priority, Long studentId);

    @Query("SELECT t FROM Ticket t WHERE (:status is null OR t.status = :status) AND (:priority is null OR t.priority = :priority) AND ((:agentId is null AND t.agent is null) OR t.agent.id = :agentId) AND (:sector is null OR t.sector = :sector) ORDER BY t.priority DESC, t.creationDate DESC")
    List<Ticket> findAgentTicketsWithFilters(Status status, Priority priority, Long agentId, Sector sector);
}